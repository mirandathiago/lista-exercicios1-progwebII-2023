<html>
    <head>
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
<div class="box resposta">
            <h2>Resultado</h2>
            <?php
//criamos variaveis locais para receber os dados vindo do formulario
  $n = $_POST['n'];  
$resul = 1;
  for($i=$numero; $i>=1;$i--){
    $n + $n;
  }
  echo "<p>{$n}</p>";
?>

